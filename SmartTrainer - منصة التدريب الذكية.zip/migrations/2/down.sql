
DROP INDEX idx_exam_attempts_exam;
DROP INDEX idx_exams_category;
DROP INDEX idx_questions_category;
DROP INDEX idx_categories_name;
DROP TABLE exam_attempts;
DROP TABLE exams;
DROP TABLE questions;
DROP TABLE categories;
