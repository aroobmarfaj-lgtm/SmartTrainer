
DROP INDEX idx_tasks_is_completed;
DROP INDEX idx_tasks_subject_id;
DROP INDEX idx_study_sessions_subject_id;
DROP INDEX idx_notes_subject_id;
DROP TABLE tasks;
DROP TABLE study_sessions;
DROP TABLE notes;
DROP TABLE subjects;
